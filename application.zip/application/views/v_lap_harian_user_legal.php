<link href="<?php echo base_url(); ?>assets/plugins/calendar/calendarorganizer.min.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/plugins/calendar/calendarorganizer.min.js"></script>
<?php
//echo '<pre>';
//var_dump($laporan);
//echo '</pre>';

// Ambil tanggal dibulan ini
$tgl_awal = date("1");
$tgl_akhir = date("t");
?>
<style>
body {
    background: #fff;
}

div.page-laporan {
    page-break-before: always;
}

pre.break {
    page-break-after: always;
}

tr {
    page-break-inside: avoid;
    page-break-after: auto;
}

table.minimalistBlack {
    border: 3px solid #000000;
    width: 100%;
    /* height: 100%; */
    text-align: left;
    border-collapse: collapse;
}

table.minimalistBlack td,
table.minimalistBlack th {
    border: 1px solid #000000;
    padding: 5px 4px;
}

table.minimalistBlack tbody td {
    font-size: 13px;
}

table.minimalistBlack thead {
    background: #CFCFCF;
    background: -moz-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
    background: -webkit-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
    background: linear-gradient(to bottom, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
    border-bottom: 3px solid #000000;
}

table.minimalistBlack thead th {
    font-size: 15px;
    font-weight: bold;
    color: #000000;
    text-align: left;
}

table.minimalistBlack tfoot {
    font-size: 14px;
    font-weight: bold;
    color: #000000;
    border-top: 3px solid #000000;
}

table.minimalistBlack tfoot td {
    font-size: 14px;
}

td.text-tengah {
    text-align: center !important;
}
</style>


<style>
td.keterangan {
    word-wrap: break-word;
    white-space: normal;
}

@media print {
    @page {
        size: landscape;
        /* size: portrait; */
    }

    body {
        background: #fff;
    }

    td .keterangan {
        word-wrap: break-word;
        white-space: pre-wrap;
    }

    pre.break {
        page-break-inside: avoid;
        page-break-after: auto
    }

    .no-print,
    .no-print * {
        display: none !important;
    }

    td.text-tengah {
        text-align: center !important;
    }

}
</style>
<title>DAFTAR LAPORAN KERJA HARIAN</title>
<div class="pcoded-main-containers">
    <div class="pcoded-wrappers">
        <div class="pcoded-contents">
            <div class="pcoded-inner-contents">
                <div class="row">
                    <?php for ($x = $tgl_awal; $x <= $tgl_akhir; $x++):
                    $tgl = date("Y-m-" . sprintf("%02d", $x));
                    $s = date("l", strtotime($tgl));
                    $hari = $this->hitungterlambat->str_indonamahari($s);
                    $tanggal = $this->durasiwaktu->tgl_indo($tgl);
                    $dis = "block";
                    $show = true;
                    if ($hari === "Sabtu" or $hari === "Minggu"){
                        $dis = "none";
                        $show = false;
                    }else{
                    ?>
                    <div class="page-laporan" style="display:<?= $dis ?>;" hari="<?= $hari ?>">
                        <div class="card">
                            <div class="card-header-s">
                                <h5>DAFTAR LAPORAN KERJA HARIAN</h5>
                            </div>
                            <div class="card-block-s">
                                <div class="table-responsive-s">
                                    <table class="minimalistBlack data-laporan">
                                        <tr>
                                            <td>Nama</td>
                                            <td colspan="5">:
                                                <?php
                                                if(isset($laporan[0])){
                                                echo $laporan[0]['nama_pegawai'];
                                                }else{
                                                    echo '-';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Unit Kerja</td>
                                            <td colspan="5">: Nama OPD</td>
                                        </tr>
                                        <tr>
                                            <td>Hari/ Tgl</td>
                                            <td colspan="5">: <?=  $hari . " / " .  $tanggal?></td>
                                        </tr>
                                        <tr>
                                            <th width="5%">No</th>
                                            <th width="10%">MULAI SELESAI</th>
                                            <th width="5%">Durasi</th>
                                            <th width="30%">RINCIAN KEGIATAN/ PEKERJAAN</th>
                                            <th width="5%">PARAF<br>ATASAN</th>
                                            <th width="5%">KET</th>
                                        </tr>

                                        <?php
                    $no = 1;
                    $times = [];
                    //echo json_encode($laporan);
                    // var_dump($laporan);
                     
                    foreach ($laporan as $data):
                        $tgl_data = $data["tgl"];
                        if($tgl_data == $tgl):
                            if ($data["status"] == 1) {
                                $times[] = $this->durasiwaktu->selisihWaktu(
                                    $data["jammulai"],
                                    $data["jamselesai"]
                                );
                            } ?>
                                        <tr>
                                            <td><?= $no ?></td>
                                            <td><?php echo substr($data["jammulai"],0, 5); ?> -
                                                <?php echo substr($data["jamselesai"],0,5); ?></td>
                                            <td><?php echo $this->durasiwaktu->selisihWaktu(
                                                    $data["jammulai"],
                                                    $data["jamselesai"]
                                                ); ?> </td>
                                            <td class="keterangan" style="word-wrap: break-word;">
                                                <?php echo $data["rincian_kegiatan"] ?>
                                            </td>
                                            <td class="text-tengah">
                                                <?php //echo $data['status'];
                                                    if (
                                                        $data["status"] == 1
                                                    ): ?>
                                                <span class="terima">✔️</span>
                                                <?php elseif (
                                                        $data["status"] == 2
                                                    ): ?>
                                                <span class="tolak">❌</span>
                                                <?php elseif (
                                                        $data["status"] == 3
                                                    ): ?>
                                                <span class="pengajuan">⚠️</span>
                                                <?php else: ?>
                                                <span class="pengajuan">⚠️</span>
                                                <?php endif; ?>
                                            </td>
                                            <td></td>
                                        </tr>
                                        <?php $no++;
                                            else:
                                        // echo '<br>'.$data["tgl"].' '.$tgl.'</br>';
                                        endif; ?>
                                        <?php endforeach; ?>
                                        <tr>
                                            <td>#</td>
                                            <td>Total Jam Kerja</td>
                                            <td colspan="5">
                                                <?= $this->durasiwaktu->SumWaktu($times) ?>
                                            </td>
                                        </tr>
                                    </table>
                                    <table class="table table-ttd" style="width: 100%;">
                                        <tr>
                                            <td width="30%" class="text-tengah">
                                                Mengetahui<br>
                                                Atasan Langsung<br>
                                                <br><br><br><br><br>
                                                <u><span class="nama-atasan">--------------------</span></u>

                                            </td>
                                            <td width="20%"></td>
                                            <td width="30%" class="text-tengah">
                                                Simpang Empat, <?= $tanggal ?><br>
                                                Yang membuat laporan<br>
                                                <br><br><br><br><br>
                                                <u>
                                                    <?php 
                                                    if(isset($laporan[0])){ 
                                                    $laporan[0]['nama_pegawai'];
                                                    }else{
                                                        echo '-';
                                                    }
                                                    ?>
                                                </u>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                                    /* 
                                    * Pege break untuk 2 halaman 
                                    * pada halaman genab
                                    */ 
                                    //     if($x % 2 == 0){
                                    //         echo '<pre class="break"></pre>'; 
                                    //     }
                                    //     else{
                                    //         echo " Odd ";
                                    //     }
                                    // echo ' nomor  '.$x 
                                    ?>
                    <!-- <pre class="break"></pre> -->

                    <?php } endfor; die; ?>
                </div>


                <div class='tab-content' style="display:none;">
                    <div id="calendarContainer"></div>
                    <div id="organizerContainer"></div>
                </div>




                <?php
 
echo "<center class='no-print'><div class='tab-content'>";
echo "<h5>LAPORAN HARIAN ABSENSI</h5>";
$nowYear = date('Y');
echo form_open(base_url('laporan_harian_controller/view'), 'target="_blank"', 'hidden');
echo "Laporan Harian : <select name='tahun'>";
echo "<option value=" . date('Y') . ">" . date('Y') . "</option>";
for ($y = 2020; $y <= $nowYear; $y++) {
    echo "<option value=" . $y . ">" . $y . "</option>";
}
echo "</select> ";
echo "<select name='bulan'>";
echo "<option value=" . date('m') . ">" . date('F') . "</option>";
for ($y = 1; $y <= 12; $y++) {
    switch ($y) {
        case '1':
            $bln = 'Januari';
            break;
        case '2':
            $bln = 'Februari';
            break;
        case '3':
            $bln = 'Maret';
            break;
        case '4':
            $bln = 'April';
            break;
        case '5':
            $bln = 'Mei';
            break;
        case '6':
            $bln = 'Juni';
            break;
        case '7':
            $bln = 'Juli';
            break;
        case '8':
            $bln = 'Agustus';
            break;
        case '9':
            $bln = 'September';
            break;
        case '10':
            $bln = 'Oktober';
            break;
        case '11':
            $bln = 'November';
            break;
        case '12':
            $bln = 'Desember';
            break;
        default:
            $bln = date('M');
            break;
    }
    echo "<option value=" . $y . ">" . $bln . "</option>";
}
echo "</select> ";

$nowYear = date('Y');
$first_day_this_month = date('01'); // hard-coded '01' for first day
$last_day_this_month  = date('m-t-Y');
$last_day_this_month_day_only = explode("-", $last_day_this_month);
echo "<select name='date'>";
echo "<option value=" . date('d') . ">" . date('d') . "</option>";
for ($dt = 1; $dt <= 31; $dt++) {
    echo "<option value=" . $dt . ">" . $dt . "</option>";
}
echo "</select> ";
echo "<button type='submit'>Tampil</button>";
echo form_close();
echo "</div></center>";
?>
            </div>
        </div>
    </div>
</div>


<script>
"use strict";
// function that creates dummy data for demonstration
function createDummyData() {
    var date = new Date();
    var data = {};

    for (var i = 0; i < 10; i++) {
        data[date.getFullYear() + i] = {};

        for (var j = 0; j < 12; j++) {
            data[date.getFullYear() + i][j + 1] = {};

            for (var k = 0; k < Math.ceil(Math.random() * 10); k++) {
                var l = Math.ceil(Math.random() * 28);

                try {
                    data[date.getFullYear() + i][j + 1][l].push({
                        startTime: "10:00",
                        endTime: "12:00",
                        text: "Some Event Here",
                        link: "https://github.com/nizarmah/calendar-javascript-lib"
                    });
                } catch (e) {
                    data[date.getFullYear() + i][j + 1][l] = [];
                    data[date.getFullYear() + i][j + 1][l].push({
                        startTime: "10:00",
                        endTime: "12:00",
                        text: "Some Event Here",
                        link: "https://github.com/nizarmah/calendar-javascript-lib"
                    });
                }
            }
        }
    }

    return data;
}

// creating the dummy static data
var data = createDummyData();

// initializing a new calendar object, that will use an html container to create itself
var calendar = new Calendar("calendarContainer", // id of html container for calendar
    "small", // size of calendar, can be small | medium | large
    [
        "Wednesday", // left most day of calendar labels
        3 // maximum length of the calendar labels
    ], [
        "#ffc107", // primary color
        "#ffa000", // primary dark color
        "#ffffff", // text color
        "#ffecb3" // text dark color
    ], {
        indicator: true,
        indicator_type: 1, // indicator type, can be 0 (not numeric) | 1 (numeric)
        indicator_pos: "bottom" // indicator position, can be top | bottom
    }
);

// initializing a new organizer object, that will use an html container to create itself
var organizer = new Organizer("organizerContainer", // id of html container for calendar
    calendar, // defining the calendar that the organizer is related to
    data // giving the organizer the static data that should be displayed
);
</script>